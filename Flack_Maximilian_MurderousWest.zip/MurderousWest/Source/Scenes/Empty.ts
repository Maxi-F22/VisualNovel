namespace Game {
    export async function Empty(): ƒS.SceneReturn {
      console.log("Ende");
    }
}